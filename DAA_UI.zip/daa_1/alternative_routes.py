import heapq

def k_shortest_paths(city_graph, start, end, k):
    """
    Find the K shortest paths between two nodes using a modified Dijkstra's algorithm.
    """
    def find_shortest_path():
        forward_queue = [(0, start, [start])]  # (cost, current_node, path_so_far)
        visited = {}
        while forward_queue:
            cost, node, path = heapq.heappop(forward_queue)
            if node in visited:
                continue
            visited[node] = path
            if node == end:
                return cost, path
            for neighbor, weight in city_graph.get_neighbors(node):
                if neighbor not in visited:
                    heapq.heappush(forward_queue, (cost + weight, neighbor, path + [neighbor]))
        return float("inf"), []

    paths = []
    for _ in range(k):
        cost, path = find_shortest_path()
        if path:
            paths.append((cost, path))
            # Invalidate the last found path to find alternative routes
            for i in range(len(path) - 1):
                edge = (path[i], path[i + 1])
                if edge in city_graph.edges:
                    del city_graph.edges[edge]
                elif (edge[1], edge[0]) in city_graph.edges:
                    del city_graph.edges[(edge[1], edge[0])]
        else:
            break
    return paths
