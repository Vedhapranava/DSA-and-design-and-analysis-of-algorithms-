import networkx as nx
import matplotlib.pyplot as plt
from city_graph import CityGraph
from resource_allocation import assign_vehicle_by_severity
from pathfinding import bidirectional_dijkstra
from alternative_routes import k_shortest_paths
from route_optimization import simulated_annealing
from graph_visualization import visualize_graph_with_path

if __name__ == "__main__":
    # Initialize the city graph
    city = CityGraph()

    # Display available locations
    print("Available Locations (Nodes):")
    for node, name in city.nodes.items():
        print(f"{node}: {name}")

    # Example incidents
    incidents = [
        {"type": "Medical", "severity": 5, "location": "3"},
        {"type": "Medical", "severity": 4, "location": "2"},
        {"type": "Medical", "severity": 3, "location": "6"}
    ]

    # Assign vehicles based on severity
    assigned_resources = assign_vehicle_by_severity("Medical", incidents, city.vehicles)

    # Output assignment results
    print("\nAssignment Results:")
    for assignment in assigned_resources:
        incident = assignment["incident"]
        vehicle = assignment["vehicle"]
        if vehicle:
            print(
                f"Incident at {incident['location']} ({city.nodes[incident['location']]}) with (Severity {incident['severity']}) "
                f"assigned to {vehicle['id']}-{vehicle['type']} at location {vehicle['location']} ({city.nodes[vehicle['location']]})"
            )
        else:
            print(
                f"Incident at {incident['location']} ({city.nodes[incident['location']]}) with (Severity {incident['severity']}) "
                f"has no available vehicle."
            )

    # Example visualization of one path
    print("\nPathfinding Results:")
    try:
        start_node = "1"  # Example start node
        end_node = "3"    # Example end node

        # Find the shortest path
        shortest_path, shortest_cost = bidirectional_dijkstra(city, start_node, end_node)

        print(f"Shortest path cost: {shortest_cost}")
        print(f"Shortest Path: {[city.nodes[node] for node in shortest_path]}")

        # Visualize the graph with the shortest path
        visualize_graph_with_path(
            city,
            shortest_path,
            "Medical",
            "graph.png",
            alternate_paths=[["1", "2", "3"], ["1", "4", "3"]]  # Example alternate paths
        )
        print("Graph visualization saved as 'graph.png'.")
    except Exception as e:
        print(f"Error during pathfinding or visualization: {str(e)}")
