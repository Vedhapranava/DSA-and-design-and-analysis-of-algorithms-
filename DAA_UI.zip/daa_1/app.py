from flask import Flask, render_template, request, jsonify, redirect, session, flash
from datetime import timedelta
import sqlite3
from city_graph import CityGraph
from pathfinding import bidirectional_dijkstra
from resource_allocation import assign_vehicle_by_severity
from graph_visualization import visualize_graph_with_path
import os
import time

app = Flask(__name__)
app.secret_key = "secret_key"
app.permanent_session_lifetime = timedelta(minutes=30)

# Ensure static directory exists
if not os.path.exists("static"):
    os.makedirs("static")

# Database Setup
def init_db():
    """Initialize the SQLite database for user authentication."""
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def cleanup_old_graphs():
    """Remove old graph files from the static directory to save space."""
    now = time.time()
    for filename in os.listdir("static"):
        if filename.startswith("graph_") and filename.endswith(".png"):
            filepath = os.path.join("static", filename)
            if now - os.path.getmtime(filepath) > 3600:  # Files older than 1 hour
                os.remove(filepath)

@app.route('/')
def index():
    """Serve the landing page."""
    if 'username' in session:
        return redirect('/home')
    return render_template("index.html")

@app.route('/home')
def home():
    """Serve the home page for logged-in users."""
    if 'username' in session:
        return render_template("home.html", username=session['username'])
    return redirect('/')

@app.route('/signup', methods=["GET", "POST"])
def signup():
    """Handle user signup."""
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]
        try:
            conn = sqlite3.connect("users.db")
            c = conn.cursor()
            c.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                      (username, email, password))
            conn.commit()
            conn.close()
            flash("Signup successful! Please log in.", "success")
            return redirect("/login")
        except sqlite3.IntegrityError:
            flash("Username or email already exists. Please try again.", "danger")
            return redirect("/signup")
    return render_template("signup.html")

@app.route('/login', methods=["GET", "POST"])
def login():
    """Handle user login."""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        conn = sqlite3.connect("users.db")
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['username'] = user[1]
            flash("Login successful!", "success")
            return redirect("/home")
        else:
            flash("Invalid credentials. Please try again.", "danger")
            return redirect("/login")
    return render_template("login.html")

@app.route('/logout')
def logout():
    """Log out the current user."""
    session.clear()
    flash("You have been logged out.", "info")
    return redirect("/")

@app.route('/report_incidents')
def report_incidents():
    """Serve the Report Incidents interface."""
    return render_template("emergency_dispatch.html")

@app.route('/allocate_resources', methods=["POST"])
def allocate_resources():
    """
    Allocate resources (vehicles) to multiple incidents.
    Assign based on type, severity, and availability.
    """
    try:
        data = request.get_json()
        incidents = data.get('incidents', [])

        # Predefine 3 ambulances, 3 fire engines, and 3 police vehicles
        vehicles = {
            "Medical": [
                {"id": "A1", "type": "Ambulance", "location": "1", "available": True},
                {"id": "A2", "type": "Ambulance", "location": "1", "available": True},
                {"id": "A3", "type": "Ambulance", "location": "1", "available": True},
            ],
            "Fire": [
                {"id": "F1", "type": "Fire Engine", "location": "5", "available": True},
                {"id": "F2", "type": "Fire Engine", "location": "5", "available": True},
                {"id": "F3", "type": "Fire Engine", "location": "5", "available": True},
            ],
            "Social": [
                {"id": "P1", "type": "Police Vehicle", "location": "10", "available": True},
                {"id": "P2", "type": "Police Vehicle", "location": "10", "available": True},
                {"id": "P3", "type": "Police Vehicle", "location": "10", "available": True},
            ],
        }

        if not incidents:
            raise ValueError("Incident data is missing.")

        city = CityGraph()

        # Assign resources based on severity and availability
        assignments = []
        for incident_type in ["Medical", "Fire", "Social"]:
            filtered_incidents = [inc for inc in incidents if inc["type"] == incident_type]
            assignments += assign_vehicle_by_severity(incident_type, filtered_incidents, vehicles)

        # Generate results with paths and graph visualization
        results = []
        for index, assignment in enumerate(assignments):
            incident = assignment["incident"]
            vehicle = assignment["vehicle"]
            if vehicle:
                shortest_path, path_cost = bidirectional_dijkstra(city, vehicle['location'], incident['location'])
                graph_file = f"static/graph_{incident['type'].lower()}_{index}.png"
                alternate_paths = [["1", "2", "5"], ["1", "3", "6"]]  # Placeholder alternate paths
                visualize_graph_with_path(city, shortest_path, incident['type'], graph_file, alternate_paths)
                results.append({
                    "incident": {
                        "location": city.nodes[incident["location"]],
                        "severity": incident["severity"],
                        "type": incident["type"]
                    },
                    "vehicle": {
                        "id": vehicle["id"],
                        "type": vehicle["type"],
                        "location": city.nodes[vehicle["location"]],
                    },
                    "shortest_path": {"path": [city.nodes[node] for node in shortest_path], "cost": path_cost},
                    "traffic_time": path_cost * 2,  # Example calculation
                    "graph": graph_file,
                })
            else:
                results.append({
                    "incident": {
                        "location": city.nodes[incident["location"]],
                        "severity": incident["severity"],
                        "type": incident["type"]
                    },
                    "vehicle": None,
                    "message": "No available vehicle for this incident"
                })

        return jsonify({"allocation": results, "vehicles_status": vehicles})

    except Exception as e:
        import traceback
        print("Error in /allocate_resources:", traceback.format_exc())
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

@app.route('/get_city_nodes', methods=["GET"])
def get_city_nodes():
    """Get city nodes dynamically for the dropdown."""
    city = CityGraph()
    return jsonify(city.nodes)

if __name__ == "__main__":
    init_db()
    cleanup_old_graphs()
    app.run(debug=True)
