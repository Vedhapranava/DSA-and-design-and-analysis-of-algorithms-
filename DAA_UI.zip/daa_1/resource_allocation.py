def assign_vehicle_by_severity(incident_type, incidents, vehicles):
    """
    Assign vehicles based on severity (higher severity gets priority).
    If no vehicle is available, the incident will have no assigned vehicle.
    """
    assigned = []  # List to store assignment results
    available_vehicles = vehicles.get(incident_type, [])

    # Sort incidents by severity in descending order
    incidents = sorted(incidents, key=lambda x: int(x['severity']), reverse=True)

    # Assign vehicles to incidents based on availability
    for incident in incidents:
        for vehicle in available_vehicles:
            if vehicle["available"]:
                vehicle["available"] = False  # Mark vehicle as unavailable
                assigned.append({
                    "incident": incident,
                    "vehicle": {"id": vehicle["id"], "type": vehicle["type"], "location": vehicle["location"]}
                })
                break
        else:
            # No available vehicle for this incident
            assigned.append({
                "incident": incident,
                "vehicle": None
            })

    return assigned
