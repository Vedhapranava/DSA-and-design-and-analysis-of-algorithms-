import random
import math

def simulated_annealing(city_graph, start, end, max_iterations=1000, initial_temp=1000):
    """
    Optimize the route using Simulated Annealing with traffic consideration.
    """
    current_path = [start]
    current_cost = 0

    def get_neighbors(node):
        """
        Get neighbors of the current node considering traffic conditions.
        """
        return city_graph.get_neighbors(node)

    temp = initial_temp
    for _ in range(max_iterations):
        if current_path[-1] == end:
            break  # Terminate if the destination is reached

        neighbors = get_neighbors(current_path[-1])
        if not neighbors:
            break  # No valid neighbors, terminate search

        next_node, edge_cost = random.choice(neighbors)
        new_cost = current_cost + edge_cost

        # Accept new path if it's better or probabilistically if worse
        if new_cost < current_cost or math.exp(-(new_cost - current_cost) / temp) > random.random():
            current_path.append(next_node)
            current_cost = new_cost

        temp *= 0.99  # Cool down temperature

    # Ensure the route reaches the destination
    if current_path[-1] != end:
        current_path.append("Route not completed")

    return current_path, current_cost
