import random

class CityGraph:
    def __init__(self):
        # Nodes (location IDs and names)
        self.nodes = {
            "1": "MG Road", "2": "Koramangala", "3": "Whitefield", "4": "Indiranagar",
            "5": "Jayanagar", "6": "Electronic City", "7": "HSR Layout", "8": "Hebbal",
            "9": "Malleshwaram", "10": "Banashankari", "11": "Marathahalli", "12": "Yelahanka",
            "13": "Sarjapur", "14": "BTM Layout", "15": "Shivajinagar", "16": "Peenya"
        }
        # Edges (connections with distances)
        self.edges = {
            ("1", "2"): 5, ("1", "3"): 10, ("2", "4"): 6, ("3", "4"): 7,
            ("4", "5"): 8, ("5", "6"): 9, ("6", "7"): 4, ("7", "8"): 6,
            ("8", "9"): 5, ("9", "10"): 7, ("10", "1"): 8, ("1", "11"): 10,
            ("11", "12"): 6, ("12", "8"): 12, ("12", "14"): 8, ("14", "13"): 9,
            ("13", "3"): 10, ("6", "13"): 6, ("5", "15"): 7, ("15", "16"): 9,
            ("16", "9"): 10
        }
        # Vehicles with their initial locations and types
        self.vehicles = {
            "Ambulance": [
                {"id": "A1", "location": "1", "available": True},
                {"id": "A2", "location": "1", "available": True},
                {"id": "A3", "location": "1", "available": True}
            ],
            "Fire Engine": [
                {"id": "F1", "location": "5", "available": True},
                {"id": "F2", "location": "5", "available": True},
                {"id": "F3", "location": "5", "available": True}
            ],
            "Police Vehicle": [
                {"id": "P1", "location": "10", "available": True},
                {"id": "P2", "location": "10", "available": True},
                {"id": "P3", "location": "10", "available": True}
            ]
        }
        # Traffic weights for edges, initialized randomly
        self.traffic_weights = {edge: random.randint(1, 5) for edge in self.edges}

    def calculate_distance(self, node1, node2):
        """
        Calculate the distance between two nodes using edge weights and traffic weights.
        Returns infinity if nodes are not directly connected.
        """
        base_distance = self.edges.get((node1, node2), self.edges.get((node2, node1), float('inf')))
        traffic = self.traffic_weights.get((node1, node2), self.traffic_weights.get((node2, node1), 0))
        return base_distance + traffic

    def get_neighbors(self, node):
        """
        Get all neighboring nodes and their traffic-adjusted distances.
        """
        neighbors = []
        for (start, end), weight in self.edges.items():
            if start == node:
                neighbors.append((end, self.calculate_distance(start, end)))
            elif end == node:
                neighbors.append((start, self.calculate_distance(end, start)))
        return neighbors

    def update_traffic(self):
        """
        Dynamically update traffic weights for all edges to simulate changing conditions.
        """
        for edge in self.traffic_weights:
            self.traffic_weights[edge] = random.randint(1, 5)
        print("Traffic conditions updated.")

    def display_traffic_conditions(self):
        """
        Display the current traffic conditions for all edges.
        """
        print("\nCurrent Traffic Conditions:")
        for (start, end), traffic in self.traffic_weights.items():
            print(f"From {self.nodes[start]} to {self.nodes[end]}: Traffic Weight = {traffic}")


if __name__ == "__main__":
    # Example usage of CityGraph
    city = CityGraph()

    # Display nodes
    print("City Nodes:")
    for node, name in city.nodes.items():
        print(f"{node}: {name}")

    # Update and display traffic conditions
    city.update_traffic()
    city.display_traffic_conditions()

    # Example: Get neighbors of a node
    print("\nNeighbors of Node 1 (MG Road):")
    for neighbor, distance in city.get_neighbors("1"):
        print(f"{city.nodes[neighbor]}: Distance = {distance}")
