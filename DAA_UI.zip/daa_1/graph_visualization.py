import networkx as nx
import matplotlib.pyplot as plt
import os


def visualize_graph_with_path(city, path, incident_type, filename, alternate_paths=None):
    """
    Visualize the graph, highlight the shortest path, and optionally highlight alternate paths.
    """
    G = nx.Graph()
    
    # Add nodes and edges
    for (start, end), weight in city.edges.items():
        G.add_edge(start, end, weight=weight)

    pos = nx.spring_layout(G, seed=42)  # Layout for visualization

    # Draw nodes
    nx.draw_networkx_nodes(G, pos, node_size=700, node_color="lightblue")
    nx.draw_networkx_labels(G, pos, labels=city.nodes, font_size=10)

    # Draw all edges
    nx.draw_networkx_edges(G, pos, edge_color="black")

    # Highlight the shortest path
    if path:
        path_edges = list(zip(path, path[1:]))
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color="red", width=2, label="Shortest Path")

    # Highlight alternate paths with dotted lines
    if alternate_paths:
        for alt_path in alternate_paths:
            alt_edges = list(zip(alt_path, alt_path[1:]))
            nx.draw_networkx_edges(G, pos, edgelist=alt_edges, edge_color="blue", style="dotted", width=1.5)

    # Draw edge labels (weights)
    edge_labels = nx.get_edge_attributes(G, "weight")
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=8)

    # Legend
    plt.legend()
    plt.title(f"{incident_type} Path Visualization")
    plt.axis("off")
    plt.savefig(filename)
    plt.close()