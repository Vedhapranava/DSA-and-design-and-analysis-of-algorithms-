import heapq

def bidirectional_dijkstra(city_graph, start, end):
    """
    Perform Bidirectional Dijkstra's Algorithm to find the shortest path and cost,
    considering traffic weights from the city graph.
    """
    # Priority queues for forward and backward search
    forward_queue = [(0, start, [start])]  # (cost, current_node, path_so_far)
    backward_queue = [(0, end, [end])]

    forward_visited = {}
    backward_visited = {}

    while forward_queue and backward_queue:
        # Forward search
        f_cost, f_node, f_path = heapq.heappop(forward_queue)
        if f_node in backward_visited:
            # Merge paths if meeting point found
            return f_path + backward_visited[f_node][1][::-1], f_cost + backward_visited[f_node][0]

        if f_node not in forward_visited:
            forward_visited[f_node] = (f_cost, f_path)
            for neighbor, weight in city_graph.get_neighbors(f_node):
                traffic_weight = city_graph.traffic_weights.get((f_node, neighbor), 
                                                                city_graph.traffic_weights.get((neighbor, f_node), 0))
                total_weight = weight + traffic_weight
                if neighbor not in forward_visited:
                    heapq.heappush(forward_queue, (f_cost + total_weight, neighbor, f_path + [neighbor]))

        # Backward search
        b_cost, b_node, b_path = heapq.heappop(backward_queue)
        if b_node in forward_visited:
            # Merge paths if meeting point found
            return forward_visited[b_node][1] + b_path[::-1], forward_visited[b_node][0] + b_cost

        if b_node not in backward_visited:
            backward_visited[b_node] = (b_cost, b_path)
            for neighbor, weight in city_graph.get_neighbors(b_node):
                traffic_weight = city_graph.traffic_weights.get((b_node, neighbor), 
                                                                city_graph.traffic_weights.get((neighbor, b_node), 0))
                total_weight = weight + traffic_weight
                if neighbor not in backward_visited:
                    heapq.heappush(backward_queue, (b_cost + total_weight, neighbor, b_path + [neighbor]))

    # If no path exists
    return [], float("inf")
