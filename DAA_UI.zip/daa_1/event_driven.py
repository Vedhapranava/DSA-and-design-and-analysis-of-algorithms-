# File: event_driven.py

def reallocate_resources(event_type, city_graph):
    """
    Handles event-driven updates for the city graph.
    
    Args:
    - event_type (str): The type of event ("traffic_update", "new_incident", etc.).
    - city_graph (CityGraph): The city graph object to be updated.

    Returns:
    - str: A message indicating the result of the event handling.
    """
    if event_type == "traffic_update":
        # Update traffic conditions on the graph
        city_graph.update_traffic()
        return "Traffic updated successfully"
    elif event_type == "new_incident":
        # Dynamically handle a new incident (e.g., add a new node or allocate a vehicle)
        # Implementation can be expanded here based on project requirements
        return "Incident handled dynamically"
    else:
        # Unknown event type
        return "Unknown event type"
